# Music-bot by YassineHz

All Copyright Go's To YassineHz.#2006

### ⚡ Installation

go to `config` folder and edit bot.json file

```js
{
    "game": "GAME",//your bot status
    "prefix": "PREFIX",//your boy prerix 
    "token_bot": "TOKEN"//your bot token
}
```

### 🛠️ Support

You Can Find Me In [Mifed Codes](http://gg.gg/y-h)

You Can Call Me In Discord : YassineHz.#2006 
