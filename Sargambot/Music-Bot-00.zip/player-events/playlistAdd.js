module.exports = (client, message, playlist) => {

    message.channel.send(`${client.emotes.music} - ${playlist.title} has been added to the queue (**${playlist.items.length}** songs) !`);
            console.log("YassineHz.#2006")
};