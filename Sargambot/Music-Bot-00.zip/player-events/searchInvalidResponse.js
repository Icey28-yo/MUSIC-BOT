module.exports = (client, message, query, tracks, content, collector) => {

    message.channel.send(`${client.emotes.error} - You must send a valid number between **1** and **${tracks.length}** !`);
            console.log("YassineHz.#2006")
};